import reflex as rx

config = rx.Config(
    app_name="webApp",
    api_url="https://webapp-tx8w.onrender.com",
    db_url="sqlite:///reflex.db",
    
)

